//
//  LocationManager.h
//  YouYou
//
//  Created by bodecn on 16/1/8.
//  Copyright © 2016年 Chen. All rights reserved.
//
typedef void(^GeoSearchBlock)(NSString *address,CGFloat lat,CGFloat lon);


#import <Foundation/Foundation.h>
#import <BaiduMapAPI_Location/BMKLocationComponent.h>//引入定位功能所有的头文件
#import <BaiduMapAPI_Search/BMKSearchComponent.h>//引入检索功能所有的头文件
#import <BaiduMapAPI_Utils/BMKUtilsComponent.h>//引入计算工具所有的头文件
#import "NSDate+FSExtension.h"

@interface LocationManager : NSObject <BMKLocationServiceDelegate,BMKGeoCodeSearchDelegate>  {
    BMKGeoCodeSearch *_search;
    NSDateFormatter *_dateFormatter;
    //定位信息
    NSDictionary *_responseTimerInfo;
}

+ (LocationManager *)ShareDistance;

@property (strong, nonatomic) BMKLocationService *locationManager;
@property (nonatomic) NSTimer* locationUpdateTimer;
//当前位置
@property (strong, nonatomic) CLLocation *currentLocation;
//当前检索的地址
@property (strong,nonatomic) NSString *currentAddress;
//当前检索的位置    通过比较当前位置判断是否应该反编码位置
@property (strong, nonatomic) CLLocation *currentSearchLocation;


@property (copy,nonatomic) GeoSearchBlock callBack;
- (void)GeoSearchWithResponse:(GeoSearchBlock)response;

- (void)startRunLoopLocation;
- (void)endRunLoopLocation;
//定位反编码
- (void)StartLocationGeoCodeSearch;
@end
