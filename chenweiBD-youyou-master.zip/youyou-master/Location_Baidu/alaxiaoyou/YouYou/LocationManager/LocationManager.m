//
//  LocationManager.m
//  YouYou
//
//  Created by bodecn on 16/1/8.
//  Copyright © 2016年 Chen. All rights reserved.
//

#import "LocationManager.h"

@implementation LocationManager

+ (LocationManager *)ShareDistance
{
    static LocationManager *data = nil;
    static dispatch_once_t onceTaken;
    dispatch_once(&onceTaken, ^{
        
        data = [[LocationManager alloc]init];
    });
    return data;
}
- (instancetype)init {
    self = [super init];
    if (self) {
        if (![CLLocationManager locationServicesEnabled]) {
            [SVProgressHUD showErrorWithStatus:@"请打开定位功能并重试！"];
        }
        self.locationManager = [[BMKLocationService alloc] init];
        self.locationManager.delegate                = self;
        self.locationManager.distanceFilter          = kCLLocationAccuracyNearestTenMeters;
        //设置允许后台定位参数，保持不会被系统挂起
        [self.locationManager setPausesLocationUpdatesAutomatically:NO];
        [self.locationManager setAllowsBackgroundLocationUpdates:YES];//iOS9(含)以上系统需设置
        [self.locationManager startUserLocationService];
        
    }
    return self;
}
//定位成功
- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation {
    NSLog(@"location:{lat:%f; lon:%f; accuracy:%f}", userLocation.location.coordinate.latitude, userLocation.location.coordinate.longitude, userLocation.location.horizontalAccuracy);
    //    //将GPS转成百度坐标
    //    NSDictionary *dic = BMKConvertBaiduCoorFrom(userLocation.location.coordinate, BMK_COORDTYPE_GPS);
    //    CLLocationCoordinate2D amapcoord = BMKCoorDictionaryDecode(dic);
    //    _currentLocation                 = [[CLLocation alloc] initWithLatitude:amapcoord.latitude longitude:amapcoord.longitude];
    _currentLocation = [[CLLocation alloc] initWithLatitude:userLocation.location.coordinate.latitude longitude:userLocation.location.coordinate.longitude];
}
- (void)didFailToLocateUserWithError:(NSError *)error {
    DLog(@"%@",error);
}
//开始第一次请求
- (void)startRunLoopLocation {
    [self.locationManager startUserLocationService];
    //延迟1开始请求服务器
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self postToServer];
    });
}
//发送到服务器
- (void)postToServer {
    if ([CLLocationManager locationServicesEnabled]) {
        
        BOOL needGeoSearch = YES;
        if (_currentAddress) {
            //1.将两个经纬度点转成投影点
            BMKMapPoint point1 = BMKMapPointForCoordinate(_currentLocation.coordinate);
            BMKMapPoint point2 = BMKMapPointForCoordinate(_currentSearchLocation.coordinate);
            //2.计算距离
            CLLocationDistance distance = BMKMetersBetweenMapPoints(point1,point2);
            //超过2公里，重新获取反编码
            if (distance < 1000) {
                needGeoSearch = NO;
            }
        }
        if (needGeoSearch) {
            //开始第一次
            [self GeoSearchWithResponse:^(NSString *address, CGFloat lat, CGFloat lon) {
                if (!_dateFormatter) {
                    _dateFormatter = [[NSDateFormatter alloc]init];
                    [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                }
                NSDictionary *dic = @{@"username":[Data Share].username,
                                      @"token":[Data Share].token,
                                      @"collec_date":[_dateFormatter stringFromDate:[NSDate date]],
                                      @"lot":[NSString stringWithFormat:@"%f",_currentLocation.coordinate.longitude],
                                      @"lat":[NSString stringWithFormat:@"%f",_currentLocation.coordinate.latitude],
                                      @"addr_info":_currentAddress};
                
                [RequestManager PostUrl:[RequestUrl SendLoc] loding:nil dic:dic response:^(id response) {
                    if (response) {
                        if ([response[@"status_code"] integerValue] == 0) {
                            
                            DLog(@"定时上报位置成功！");
                            //开始定时上传坐标
                            [self startTimer:response];
                        }
                    }
                }];
            }];
            
        }
        else {
            if (!_dateFormatter) {
                _dateFormatter = [[NSDateFormatter alloc]init];
                [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            }
            NSDictionary *dic = @{@"username":[Data Share].username,
                                  @"token":[Data Share].token,
                                  @"collec_date":[_dateFormatter stringFromDate:[NSDate date]],
                                  @"lot":[NSString stringWithFormat:@"%f",_currentLocation.coordinate.longitude],
                                  @"lat":[NSString stringWithFormat:@"%f",_currentLocation.coordinate.latitude],
                                  @"addr_info":_currentAddress};
            
            [RequestManager PostUrl:[RequestUrl SendLoc] loding:nil dic:dic response:^(id response) {
                if (response) {
                    if ([response[@"status_code"] integerValue] == 0) {
                        
                        DLog(@"定时上报位置成功！");
                        //开始定时上传坐标
                        [self startTimer:response];
                    }
                }
            }];
            
        }
    }
}


//检索地址
- (void)GeoSearchWithResponse:(GeoSearchBlock)response {
    self.callBack = response;
    [self StartLocationGeoCodeSearch];
}

//定位反编码
- (void)StartLocationGeoCodeSearch {
    if ([CLLocationManager locationServicesEnabled]) {
        
        
        //        //创建位置
        //        CLGeocoder *revGeo = [[CLGeocoder alloc] init];
        //        [revGeo reverseGeocodeLocation:_currentLocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        //           //
        ////            DLog(@"%@",placemarks);
        //            if (error == nil &&
        //                [placemarks count] > 0){
        //
        //
        //                CLPlacemark *placemark = [placemarks objectAtIndex:0];
        //                NSLog(@"当前坐标%@",_currentLocation);
        //                NSLog(@"Country = %@", placemark.country);
        //                NSLog(@"Postal Code = %@", placemark.postalCode);
        //                NSLog(@"Locality = %@", placemark.locality);
        //                NSLog(@"Locality = %@", placemark.name);
        //            }
        //            else if (error == nil &&
        //                     [placemarks count] == 0){
        //                NSLog(@"No results were returned.");
        //            }
        //            else if (error != nil){
        //                NSLog(@"An error occurred = %@", error);
        //            }
        //        }];
        
        //初始化检索对象
        if (!_search) {
            _search = [[BMKGeoCodeSearch alloc] init];
            _search.delegate = self;
        }
        
        //发起反向地理编码检索
        
        CLLocationCoordinate2D pt                           = _currentLocation.coordinate;
        BMKReverseGeoCodeOption *reverseGeoCodeSearchOption = [[BMKReverseGeoCodeOption alloc]init];
        reverseGeoCodeSearchOption.reverseGeoPoint          = pt;
        BOOL flag = [_search reverseGeoCode:reverseGeoCodeSearchOption];
        if(flag)
        {
            NSLog(@"反geo检索发送成功%@",_currentLocation);
        }
        else
        {
            NSLog(@"反geo检索发送失败");
        }
    }
    else {
        [SVProgressHUD showErrorWithStatus:@"请打开定位功能并重试！"];
    }
}
//接收反向地理编码结果
-(void) onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error{
    if (error == BMK_SEARCH_NO_ERROR) {
        //在此处理正常结果
        //通过AMapReGeocodeSearchResponse对象处理搜索结果
        //        NSString *result = [NSString stringWithFormat:@"ReGeocode: %@", response.regeocode];
        NSLog(@"ReGeo: %@", result.address);
        //当前位置
        _currentAddress        = result.address;
        //当前检索位置
        _currentSearchLocation = _currentLocation;
        NSLog(@"进行地理位置反编码: %@", result.address);
        if (self.callBack) {
            self.callBack(result.address,_currentLocation.coordinate.latitude,_currentLocation.coordinate.longitude);
        }
    }
    else {
        NSLog(@"抱歉，未找到结果");
        if (self.callBack) {
            self.callBack(nil,0,0);
        }
    }
    self.callBack    = nil;
    _search.delegate = nil;
    _search          = nil;
}
////实现逆地理编码的回调函数
//- (void)onReGeocodeSearchDone:(AMapReGeocodeSearchRequest *)request response:(AMapReGeocodeSearchResponse *)response
//{
//    if(response.regeocode != nil)
//    {
//        //通过AMapReGeocodeSearchResponse对象处理搜索结果
//        //        NSString *result = [NSString stringWithFormat:@"ReGeocode: %@", response.regeocode];
//        if (response.regeocode.formattedAddress.length > 0) {
//            //当前位置
//            _currentAddress        = response.regeocode.formattedAddress;
//            //当前检索位置
//            _currentSearchLocation = _currentLocation;
//            NSLog(@"进行地理位置反编码: %@", response.regeocode.formattedAddress);
//            if (self.callBack) {
//                self.callBack(response.regeocode.formattedAddress,_currentLocation.coordinate.latitude,_currentLocation.coordinate.longitude);
//            }
//        }
//    }
//    else
//    {
//        if (self.callBack) {
//            self.callBack(nil,0,0);
//        }
//    }
//    //将请求置为nil  避免多次请求造成错误
//    _regeo = nil;
//}

//第一次请求完成
- (void)startTimer:(NSDictionary *)dic {
    _responseTimerInfo = dic;
    if (self.locationUpdateTimer) {
        [self.locationUpdateTimer invalidate];
        self.locationUpdateTimer = nil;
    }
    //设定向服务器发送位置信息的时间间隔
    NSTimeInterval time = 20 * 60;
    if (dic) {
        if (dic[@"sep_min"]) {
            time = [dic[@"sep_min"] integerValue] * 60;
        }
        
    }
    //开启计时器
    self.locationUpdateTimer =
    [NSTimer scheduledTimerWithTimeInterval:time
                                     target:self
                                   selector:@selector(updateLocation)
                                   userInfo:nil
                                    repeats:YES];
    [[NSRunLoop currentRunLoop]addTimer:self.locationUpdateTimer forMode:NSDefaultRunLoopMode];
}
-(void)updateLocation {
    
    NSInteger startTime = 0;
    NSInteger stopTime = 24;
    NSDate *date = [NSDate date];
    if (_responseTimerInfo) {
        
        startTime = [_responseTimerInfo[@"begin_hour"] integerValue];
        stopTime  = [_responseTimerInfo[@"end_hour"] integerValue];
        //起始时间为整数
        if ([[NSString stringWithFormat:@"%@",_responseTimerInfo[@"begin_hour"]] length] <= 2) {
            //结束时间为整数
            if ([[NSString stringWithFormat:@"%@",_responseTimerInfo[@"end_hour"]] length] <= 2) {
                
                if (date.fs_hour >= startTime && date.fs_hour < stopTime) {
                    DLog(@"开始获取定位信息...");
                    //向服务器发送位置信息
                    [self postToServer];
                }
            }
            else {
                //结束时间不为整数
                
                if (date.fs_hour >= startTime && date.fs_hour <= stopTime) {
                    NSLog(@"开始获取定位信息...");
                    if (date.fs_hour == stopTime) {
                        if (date.fs_minute <= 30) {
                            [self postToServer];
                        }
                    }
                    else {
                        NSLog(@"开始获取定位信息...");
                        //向服务器发送位置信息
                        [self postToServer];
                    }
                }
            }
        }
        else {
            //结束时间为整数
            if ([[NSString stringWithFormat:@"%@",_responseTimerInfo[@"end_hour"]] length] <= 2) {
                
                if (date.fs_hour >= startTime && date.fs_hour < stopTime) {
                    NSLog(@"开始获取定位信息...");
                    if (date.fs_hour == startTime) {
                        if (date.fs_minute >= 30) {
                            //向服务器发送位置信息
                            [self postToServer];
                        }
                    }
                    else {
                        //向服务器发送位置信息
                        [self postToServer];
                    }
                }
            }
            else {
                //结束时间不为整数
                
                if (date.fs_hour >= startTime && date.fs_hour <= stopTime) {
                    NSLog(@"开始获取定位信息...");
                    if (date.fs_hour == startTime) {
                        if (date.fs_minute >= 30) {
                            //向服务器发送位置信息
                            [self postToServer];
                        }
                    }
                    else if (date.fs_hour == stopTime) {
                        if (date.fs_minute <= 30) {
                            //向服务器发送位置信息
                            [self postToServer];
                        }
                    }
                    else {
                        //向服务器发送位置信息
                        [self postToServer];
                    }
                }
            }
        }
    }
    else {
        if (date.fs_hour >= startTime && date.fs_hour < stopTime) {
            NSLog(@"开始获取定位信息...");
            //向服务器发送位置信息
            [self postToServer];
        }
    }
    
}
- (void)endRunLoopLocation {
    if (self.locationUpdateTimer) {
        [self.locationUpdateTimer invalidate];
        self.locationUpdateTimer = nil;
    }
    [self.locationManager stopUserLocationService];
}


@end
