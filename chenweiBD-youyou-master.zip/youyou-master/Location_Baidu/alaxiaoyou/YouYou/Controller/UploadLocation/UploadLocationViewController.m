//
//  UploadLocationViewController.m
//  YouYou
//
//  Created by Chen on 15/7/5.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import "UploadLocationViewController.h"
#import "LocationManager.h"

@interface UploadLocationViewController ()
{
    NSString *lat;
    NSString *lon;
}
@property (weak, nonatomic) IBOutlet UILabel *CustomName;
@property (weak, nonatomic) IBOutlet UILabel *LocationLabel;
@property (weak, nonatomic) IBOutlet UIButton *LocationBtn;
@property (weak, nonatomic) IBOutlet UIButton *UploadBtn;

@end

@implementation UploadLocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setTitle:@"上传门店坐标"];
    [self initBack];
    [self btnStatus:self.LocationBtn];
    [self btnStatus:self.UploadBtn];
    
    if (_cus_Info) {
        self.CustomName.text = [NSString stringWithFormat:@"%@",self.cus_Info[@"cust_name"]];
    }
    
    [self locationClick:nil];
}

- (void)btnStatus:(UIButton *)btn
{
    btn.layer.borderWidth = 0.5;
    btn.layer.borderColor = RGBA(202, 202, 202, 1).CGColor;
    btn.layer.shadowColor = RGBA(202, 202, 202, 1).CGColor;
    btn.layer.cornerRadius = 8;
}

- (IBAction)locationClick:(id)sender {
    if ([CLLocationManager locationServicesEnabled]) {
    [SVProgressHUD showWithStatus:@"定位中..."];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            lat = [NSString stringWithFormat:@"%f",[LocationManager ShareDistance].currentLocation.coordinate.latitude];
            lon = [NSString stringWithFormat:@"%f",[LocationManager ShareDistance].currentLocation.coordinate.longitude];
            [SVProgressHUD showSuccessWithStatus:@"定位成功!"];
        });
    }
    else {
        [SVProgressHUD showSuccessWithStatus:@"定位失败!"];
    }
    
}
- (IBAction)UploadClick:(id)sender {
    if (lat && lon) {
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        [dateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
        dateFormatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
        NSDate *date = [NSDate date];
        NSString *dateStr = [dateFormatter stringFromDate:date];
        
        NSDictionary *dic = @{@"username":[Data Share].username,
                              @"token":[Data Share].token,
                              @"collec_date":dateStr,
                              @"lot":lon,
                              @"lat":lat,
                              @"cust_id":self.cus_Info[@"cust_id"],
                              @"cust_code":self.cus_Info[@"cust_code"],
                              @"cust_name":self.cus_Info[@"cust_name"]};
        
        [RequestManager PostUrl:[RequestUrl SendStoreLoc] loding:@"正在上传..." dic:dic response:^(id response) {
            if (response) {
                if ([response[@"status_code"] integerValue] == 0) {
                    [SVProgressHUD showSuccessWithStatus:response[@"tip_msg"]];
                }
                else {
                    [SVProgressHUD showErrorWithStatus:response[@"tip_msg"]];
                }
                
            }
            else {
                [SVProgressHUD showErrorWithStatus:@"网络请求失败!"];
            }
            
        }];

    }
}

@end
