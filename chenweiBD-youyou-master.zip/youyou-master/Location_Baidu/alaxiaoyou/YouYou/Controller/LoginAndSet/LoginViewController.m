//
//  LoginViewController.m
//  YouYou
//
//  Created by Chen on 15/6/29.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import "LoginViewController.h"
#import "SetServiceViewController.h"
#import "AppDelegate.h"
#import "MianViewController.h"
#import "UIDevice+FCUUID.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameText;
@property (weak, nonatomic) IBOutlet UITextField *passwordText;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UIButton *remName;
@property (weak, nonatomic) IBOutlet UIButton *remPassword;

@end

@implementation LoginViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setTitle:@"用户登录"];
    [self btnStatus:_loginBtn];
    
    
    if ([UserData keyForUser:@"password"] || [UserData keyForUser:@"username"]) {
        _nameText.text = [UserData keyForUser:@"username"];
        _remName.selected = YES;
    }
    if ([UserData keyForUser:@"password"]) {
        _passwordText.text = [UserData keyForUser:@"password"];
        _remPassword.selected = YES;
        [self login:nil];
    }
    NSLog(@"当前设备码:%@",[[UIDevice currentDevice] uuid]);

}

- (void)btnStatus:(UIButton *)btn
{
    btn.layer.borderWidth = 0.5;
    btn.layer.borderColor = RGBA(202, 202, 202, 1).CGColor;
    btn.layer.shadowColor = RGBA(202, 202, 202, 1).CGColor;
    btn.layer.cornerRadius = 8;
}
- (IBAction)remName:(UIButton *)sender {
    sender.selected = !sender.selected;
    
}
- (IBAction)login:(id)sender {
    if (_nameText.text.length == 0 || _passwordText.text.length == 0) {
        [SVProgressHUD showErrorWithStatus:@"请输入登录账号和密码!"];
    }
    else {
        [_loginBtn setTitle:@"登录中" forState:UIControlStateNormal];
        
        NSString *udid = [[UIDevice currentDevice] uuid];
        if (udid.length > 16) {
            udid = [udid substringToIndex:16];
        }
        
        NSDictionary *dic = @{@"username":_nameText.text,
                              @"password":_passwordText.text,
                              @"imei":udid};
        [RequestManager PostUrl:[RequestUrl Login] loding:@"登录中..." dic:dic
                       response:^(id response) {
            if (response) {
                if ([response[@"status_code"] integerValue] == 0) {
                    [SVProgressHUD showSuccessWithStatus:response[@"tip_msg"]];
                    if (response[@"token"]) {
                        [UserData Value:response[@"token"] forKey:@"token"];
                    }
                    [self setLoginInfo:response[@"token"]];
                }
                else {
                    [SVProgressHUD showErrorWithStatus:response[@"tip_msg"]];
                }
                
            }
            else{
                [SVProgressHUD showErrorWithStatus:@"网络连接失败！"];
            }
            [_loginBtn setTitle:@"登录" forState:UIControlStateNormal];
        }];
    }
}

- (void)setLoginInfo:(NSString *)token
{
    [UserData Value:_nameText.text forKey:@"username"];
    
    if (_remPassword.selected) {
        [UserData Value:_passwordText.text forKey:@"password"];
    }
    else {
        [UserData Deletekey:@"password"];
    }
    if (_remName.selected || _remPassword.selected) {
        [UserData Value:@"1" forKey:@"remberName"];
    }
    else {
        [UserData Deletekey:@"username"];
    }
    //将信息放在单例。
    [Data Share].username = _nameText.text;
    [Data Share].token = token;
    //
    [[Data Share] initData:@{@"username":[Data Share].username,
                             @"token":[Data Share].token}];
    [[Data Share] initOrgadefquery];
    
    
    MianViewController *vc = [[MianViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];

}
- (IBAction)EditAddress:(id)sender {
    SetServiceViewController *vc = [[SetServiceViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)dealloc
{
    DLog(@"");
}
#pragma mark -- 获取唯一标识

- (void)loadOnlyOne {
    NSString *identifierStr = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    NSString * const KEY_USERNAME_PASSWORD = @"com.snda.app.usernamepassword";
    NSString * const KEY_PASSWORD = @"com.snda.app.password";
    NSMutableDictionary *usernamepasswordKVPairs = [NSMutableDictionary dictionary];
    [usernamepasswordKVPairs setObject:identifierStr forKey:KEY_PASSWORD];
    
    
    //存
    [self save:KEY_USERNAME_PASSWORD data:usernamepasswordKVPairs];
    
    NSMutableDictionary *readUserPwd = (NSMutableDictionary *)[self load:KEY_USERNAME_PASSWORD];
    NSLog(@"%@",readUserPwd);
}
//存
- (void)save:(NSString *)service data:(id)data {
    //Get search dictionary
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    //Delete old item before add new item
    SecItemDelete((__bridge CFDictionaryRef)keychainQuery);
    //Add new object to search dictionary(Attention:the data format)
    [keychainQuery setObject:[NSKeyedArchiver archivedDataWithRootObject:data] forKey:(__bridge id)kSecValueData];
    //Add item to keychain with the search dictionary
    SecItemAdd((__bridge CFDictionaryRef)keychainQuery, NULL);
}

- (NSMutableDictionary *)getKeychainQuery:(NSString *)service {
    return [NSMutableDictionary dictionaryWithObjectsAndKeys:
            (__bridge id)kSecClassGenericPassword,(__bridge id)kSecClass,
            service, (__bridge id)kSecAttrService,
            service, (__bridge id)kSecAttrAccount,
            (__bridge id)kSecAttrAccessibleAfterFirstUnlock,(__bridge id)kSecAttrAccessible,
            nil];
}

//取
- (id)load:(NSString *)service {
    id ret = nil;
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    //Configure the search setting
    //Since in our simple case we are expecting only a single attribute to be returned (the password) we can set the attribute kSecReturnData to kCFBooleanTrue
    [keychainQuery setObject:(__bridge id)kCFBooleanTrue forKey:(__bridge id)kSecReturnData];
    [keychainQuery setObject:(__bridge id)kSecMatchLimitOne forKey:(__bridge id)kSecMatchLimit];
    CFDataRef keyData = NULL;
    if (SecItemCopyMatching((__bridge CFDictionaryRef)keychainQuery, (CFTypeRef *)&keyData) == noErr) {
        @try {
            ret = [NSKeyedUnarchiver unarchiveObjectWithData:(__bridge NSData *)keyData];
        } @catch (NSException *e) {
            NSLog(@"Unarchive of %@ failed: %@", service, e);
        } @finally {
        }
    }
    if (keyData)
        CFRelease(keyData);
    return ret;
}


- (void)delete:(NSString *)service {
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    SecItemDelete((__bridge CFDictionaryRef)keychainQuery);
}
@end
