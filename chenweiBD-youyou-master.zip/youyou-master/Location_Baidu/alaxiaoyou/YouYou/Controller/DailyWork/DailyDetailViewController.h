//
//  DailyDetailViewController.h
//  YouYou
//
//  Created by Chen on 15/7/2.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import "BaseViewController.h"

@interface DailyDetailViewController : BaseViewController

@property(strong) NSString *today;
@property(assign)BOOL isPlan;

@end
