//
//  NewWorkViewController.h
//  YouYou
//
//  Created by Chen on 15/7/7.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import "BaseViewController.h"

@interface NewWorkViewController : BaseViewController

@property (strong) NSDate *date;

@property (assign) BOOL isPlan;

@end
