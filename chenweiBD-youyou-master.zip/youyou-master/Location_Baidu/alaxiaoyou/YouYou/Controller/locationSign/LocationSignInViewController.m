//
//  LocationSignInViewController.m
//  YouYou
//
//  Created by Chen on 15/6/28.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import "LocationSignInViewController.h"
#import "LocationManager.h"

@interface LocationSignInViewController () <ZSYPopoverListDatasource,ZSYPopoverListDelegate>
{
    NSArray *_selectArrray;
    CGFloat _lat;
    CGFloat _lon;
}
@property (weak, nonatomic) IBOutlet UIButton *Select;
@property (strong) NSIndexPath *selectedIndexPath;
@property (weak, nonatomic) IBOutlet UIButton *Location;
@property (weak, nonatomic) IBOutlet UIButton *Sure;
@property (weak, nonatomic) IBOutlet UITextField *LocationText;

@end

@implementation LocationSignInViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.signIn ? [self setTitle:@"位置签到"] : [self setTitle:@"位置签退"];
    [self initBackBtn];
    
    UIImage *image2 = [UIImage imageNamed:@"select_a_bg.9"];
    image2 = [image2 stretchableImageWithLeftCapWidth:floorf(image2.size.width/2) topCapHeight:floorf(image2.size.height/2)];
    [_Select setBackgroundImage:image2 forState:UIControlStateNormal];
    
    
    
    [self btnStatus:_Location];
    [self btnStatus:_Sure];
    
    [self StartLocation:nil];
    
    
}
-(void)initBackBtn
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *backImage = [UIImage imageNamed:@"btn_back_on"];
    button.frame = CGRectMake(0, 0, 98 * 0.6, 47 * 0.6);
    [button setBackgroundImage:backImage forState:UIControlStateNormal];
    [button addTarget:self action:@selector(goback) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = item;
    
}
- (void)goback
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)btnStatus:(UIButton *)btn
{
    btn.layer.borderWidth = 0.5;
    btn.layer.borderColor = RGBA(202, 202, 202, 1).CGColor;
    btn.layer.shadowColor = RGBA(202, 202, 202, 1).CGColor;
    btn.layer.cornerRadius = 8;
}
- (IBAction)ChooseCustom:(id)sender {
    if ([Data Share].CustomArray) {
        
        _selectArrray = [Data Share].CustomArray;
        NSInteger count = _selectArrray.count;
        if ((ScreenHeight - 80) / 44 < count) {
            count = (ScreenHeight - 80) / 44;
        }
        ZSYPopoverListView *listView = [[ZSYPopoverListView alloc] initWithFrame:CGRectMake(10, 0, ScreenWidth - 20, count * 44 + 32)];
        listView.titleName.text = @"客户/门店";
        listView.datasource = self;
        listView.delegate = self;
        //    [listView setCancelButtonTitle:@"Cancel" block:^{
        //        DLog(@"cancel");
        //    }];
        //    [listView setDoneButtonWithTitle:@"OK" block:^{
        //        DLog(@"Ok%d", [listView indexPathForSelectedRow].row);
        //    }];
        [listView show];
    }
}
//定位
- (IBAction)StartLocation:(id)sender {
    
    if ([CLLocationManager locationServicesEnabled]) {
        
        [SVProgressHUD showWithStatus:@"定位中..."];
        CGFloat timeAfter = 5;
        if ([LocationManager ShareDistance].currentAddress) {
            
            //1.将两个经纬度点转成投影点
            BMKMapPoint point1 = BMKMapPointForCoordinate([LocationManager ShareDistance].currentLocation.coordinate);
            BMKMapPoint point2 = BMKMapPointForCoordinate([LocationManager ShareDistance].currentSearchLocation.coordinate);
            //2.计算距离
            CLLocationDistance distance = BMKMetersBetweenMapPoints(point1,point2);
            //超过2公里，重新获取反编码
            if (distance > 1000) {
                [[LocationManager ShareDistance] StartLocationGeoCodeSearch];
            }
            else {
                timeAfter = 1;
            }
            
        }
        else {
            [[LocationManager ShareDistance] StartLocationGeoCodeSearch];
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(timeAfter * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            if ([LocationManager ShareDistance].currentAddress) {
                _LocationText.text = [LocationManager ShareDistance].currentAddress;
                _lat               = [LocationManager ShareDistance].currentLocation.coordinate.latitude;
                _lon               = [LocationManager ShareDistance].currentLocation.coordinate.longitude;
                [SVProgressHUD showSuccessWithStatus:@"定位成功！"];
            }
            else {
                _LocationText.text = @"获取地址失败，请重试！";
                [SVProgressHUD showErrorWithStatus:@"获取地址失败，请重试！"];
            }
            
        });
    }
    else {
        [SVProgressHUD showErrorWithStatus:@"请打开定位功能并重试！"];
    }
    
    //
    //    [[LocationManager ShareDistance] GeoSearchWithResponse:^(NSString *address, CGFloat lat, CGFloat lon) {
    //
    //        if (address) {
    //            _LocationText.text = address;
    //            _lat               = lat;
    //            _lon               = lon;
    //            [SVProgressHUD showSuccessWithStatus:@"定位成功！"];
    //        }
    //        else {
    //            _LocationText.text = @"地理位置获取失败，请检查网络是否良好！";
    //            [SVProgressHUD showErrorWithStatus:@"地理位置获取失败，请检查网络是否良好！"];
    //        }
    //
    //    }];
}

//
- (IBAction)SureClick:(id)sender {
    if ([CLLocationManager locationServicesEnabled] && _LocationText.text.length > 0) {
        NSDictionary *dic = @{@"username":[Data Share].username,
                              @"token":[Data Share].token,
                              @"sign_type":self.signIn ? @"in" : @"out",
                              @"point_x":[NSString stringWithFormat:@"%f",_lon],
                              @"point_y":[NSString stringWithFormat:@"%f",_lat],
                              @"addr_info":_LocationText.text};
        
        [RequestManager PostUrl:[RequestUrl Sign] loding:@"Loading..." dic:dic response:^(id response) {
            if (response) {
                if ([response[@"status_code"] integerValue] == 0) {
                    [SVProgressHUD showSuccessWithStatus:response[@"tip_msg"]];
                    [self goback];
                }
                else {
                    [SVProgressHUD showErrorWithStatus:response[@"tip_msg"]];
                }
                
            }
            else {
                [SVProgressHUD showErrorWithStatus:@"网络请求失败!"];
            }
            
        }];
        
    }
    else {
        [SVProgressHUD showErrorWithStatus:@"当前信息有误！请确认!"];
    }
}
#pragma mark -
- (NSInteger)popoverListView:(ZSYPopoverListView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _selectArrray ? _selectArrray.count : 0;
    
}

- (UITableViewCell *)popoverListView:(ZSYPopoverListView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"identifier";
    UITableViewCell *cell = [tableView dequeueReusablePopoverCellWithIdentifier:identifier];
    if (nil == cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    if ( self.selectedIndexPath && NSOrderedSame == [self.selectedIndexPath compare:indexPath])
    {
        cell.imageView.image = [UIImage imageNamed:@"fs_main_login_selected.png"];
    }
    else
    {
        cell.imageView.image = [UIImage imageNamed:@"fs_main_login_normal.png"];
    }
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    cell.textLabel.text = _selectArrray[indexPath.row][@"cust_name"];//[NSString stringWithFormat:@"-dsds---%ld------", (long)indexPath.row];
    return cell;
}

- (void)popoverListView:(ZSYPopoverListView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView popoverCellForRowAtIndexPath:indexPath];
    cell.imageView.image = [UIImage imageNamed:@"fs_main_login_normal.png"];
    //    DLog(@"deselect:%ld", (long)indexPath.row);
}

- (void)popoverListView:(ZSYPopoverListView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.selectedIndexPath = indexPath;
    UITableViewCell *cell = [tableView popoverCellForRowAtIndexPath:indexPath];
    cell.imageView.image = [UIImage imageNamed:@"fs_main_login_selected.png"];
    [self.Select setTitle:[NSString stringWithFormat:@"  %@",_selectArrray[indexPath.row][@"cust_name"]] forState:UIControlStateNormal];
    self.LocationText.text = [NSString stringWithFormat:@"%@",_selectArrray[indexPath.row][@"cust_addr"]];
}

@end
