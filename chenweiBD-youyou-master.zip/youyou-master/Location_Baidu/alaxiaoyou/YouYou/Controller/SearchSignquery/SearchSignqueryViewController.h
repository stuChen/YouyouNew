//
//  SearchSignqueryViewController.h
//  YouYou
//
//  Created by Chen on 15/7/4.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import "BaseViewController.h"

@interface SearchSignqueryViewController : BaseViewController

@property(strong)NSDictionary *dict;
//是否显示异常
@property(assign)BOOL Show_exp;

@end
