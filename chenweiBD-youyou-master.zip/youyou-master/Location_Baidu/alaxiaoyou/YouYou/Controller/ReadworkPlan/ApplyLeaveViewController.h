//
//  ApplyLeaveViewController.h
//  YouYou
//
//  Created by Chen on 15/7/13.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import "BaseViewController.h"

@interface ApplyLeaveViewController : BaseViewController

@end
