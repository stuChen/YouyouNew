//
//  ReadWorkPlanDetailViewController.h
//  YouYou
//
//  Created by Chen on 15/7/10.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import "BaseViewController.h"

@interface ReadWorkPlanDetailViewController : BaseViewController

@property (strong) NSDictionary *userInfo;

@property (assign) BOOL isLog;

@end
