//
//  DatePickerBtn.h
//  YouYou
//
//  Created by Chen on 15/7/13.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectDatePicker.h"

@interface DatePickerBtn : UIButton

@property (strong)SelectDatePicker *datePicker;
@end
