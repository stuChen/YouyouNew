//
//  YY_Button.h
//  YouYou
//
//  Created by Chen on 15/6/28.
//  Copyright (c) 2015年 Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YY_Button : UIButton
- (instancetype)initWithFrame:(CGRect)frame image:(NSString *)image title:(NSString *)title;
@end
